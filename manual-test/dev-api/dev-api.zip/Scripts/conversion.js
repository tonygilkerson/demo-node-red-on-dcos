﻿var expression = require('./expressionBuilder');
var fs = require('fs');

var ruleFile = "";
var filter = "";
process.argv.forEach(function (val, index, array) {
    ruleFile = val;
});

//load the filter from file
fs.readFile(ruleFile, { encoding: 'utf-8' }, function (err, data) {
    if (err) {
        return console.log(err);
    }
    filter = data;

    var query = expression(JSON.parse(filter));

    fs.writeFile(ruleFile, JSON.stringify(query.query), function (err) {
        if (err) {
            console.log(err);
        } else {
            console.log("The file was saved!");
        }
    });

    //  console.log(JSON.stringify(query.query));
    //console.log(data);
});


