﻿/**
 * Filter converter to MongoDB filter
 * author: afreeland
 */


var regex = {

    /**
	 * Sequence of words are independent and order does not matter
	 * @return {string} Returns regular expression based on arguments
	 * #Example
	 * passing in ('jack', 'james') results in
	 * "^(?=.*\bjack\b)(?=.*\bjames\b).*$"
	 */
    orthogonalContains: function () {
        var _len = arguments.length, expression = '';
        for (var i = 0; i < _len; i++) {
            expression += '(?=.*\\b' + arguments[i] + '\\b)';
        }
        return '^' + expression + '.*$';
    },

    /**
	 * Search for a single keyword instance, matching anything before/after
	 * @param  {string} keyword Word to search for
	 * @return {string}
	 */
    contains: function (keyword) {
        return '^.*' + keyword + '.*$';
    },

    /**
	 * Regular expression to match where line does NOT contain the keyword
	 * @param  {string} keyword Word/characters that are NOT desired to match
	 * @return {string}
	 */
    doesNotContain: function (keyword) {
        return '^((?!' + keyword + ').)*$';
    },

    /**
	 * Simply matches where beginning of line matches keyword
	 * @param  {} keyword Word/characters that line needs to begin with
	 * @return {string}
	 */
    beginsWith: function (keyword) {
        return '^' + keyword + '.*';
    },

    /**
	 * Fast pattern for matching a begins with and and ends with value
	 * @param  {string} bw What it needs to Begins With
	 * @param  {string} ew What it needs to End With
	 * @return {string}
	 */
    beginsAndEndsWith: function (bw, ew) {
        return '\\b' + bw + '\\.\\w+' + ew + '\\b';
    },

    /**
	 * Does Not Begin with expression
	 * @param  {string} keyword Term that the line should NOT start with
	 * @param  {string} type    Type of regex to use [lookAhead|lookBehind]
	 * @return {string}
	 */
    doesNotBeginWith: function (keyword, type) {
        type = type || 'lookAhead';
        var types = {
            lookAhead: '^(?!' + keyword + ').+',
            lookBehind: '(^.{1,3}$|^.{4}(?<!' + keyword + ').*)'
        };
        return types[type];
    },

    /**
	 * Ends With expression
	 * @param  {string} keyword Term that the line should End With
	 * @return {string}
	 *
	 * #Explanation
	 * \w* - allows word characters in front of [keyword]
	 * \b - boundary assertion that the word [keyword] is at the end
	 */
    endsWith: function (keyword) {
        return '\\w*' + keyword + '$';
    },

    /**
	 * Does Not End With
	 * @param  {string} keyword Term that the line should NOT end with
	 * @return {string}
	 *
	 * #Explanation
	 * (?<! [keyword] ) - Negated look behind assertion that ensures before
	 * the end of our line ($) our keyword is there
	 */
    doesNotEndWith: function (keyword) {
        //return '.*(?<!' + keyword + ')$';
        return '^(?!.*' + keyword + '$)[/\\w\\.-]+$';
    }
};



function Expression(rule) {
    var self = this;

    // Field that we want to create a mongo expression for
    this.field = rule.field;

    // the operator or value needed for query, which can take many forms
    // field: 5
    // field: 'some string'
    // field: { $regex: 'pattern'}
    // field: { $lt: 12 }
    this.operator = {};

    // Cache off #JustBecause
    this._originalOperator = rule.op;

    this.data = rule.data;

    // The finally rendered query for this rule
    this.query = null;

    this.convertOperator();

}

Expression.prototype.convertOperator = function () {
    switch (this._originalOperator) {
        case 'bw':
            this.beginsWith();
            break;
        case 'bn':
            this.doesNotBeginWith();
            break;
        case 'eq':
            this.operator = this.data;
            break;
        case 'ne':
            this.mappedOperator('$ne');
            break;
        case 'ew':
            this.endsWith();
            break;
        case 'en':
            this.doesNotEndWith();
            break;
        case 'cn':
            this.contains();
            break;
        case 'nc':
            this.doesNotContain();
            break;
        case 'oc':
            this.orthogonalContains();
            break;
        case 'lt':
            this.mappedOperator('$lt');
            break;
        case 'le':
            this.mappedOperator('$lte');
            break;
        case 'gt':
            this.mappedOperator('$gt');
            break;
        case 'ge':
            this.mappedOperator('$gte');
            break;
        case 'nu':
            this.isNull();
            break;
        case 'nn':
            this.isNotNull();
            break;
        case 'in':
            this.in();
            break;
        case 'ni':
            this.notIn();
            break;
        default:
            break;
    }
};

Expression.prototype.beginsWith = function () {
    var _regex = regex.beginsWith(this.data);
    this.operator = this.regex(_regex);
};

Expression.prototype.doesNotBeginWith = function () {
    var _regex = regex.doesNotBeginWith(this.data);
    this.operator = this.regex(_regex);
};

Expression.prototype.endsWith = function () {
    var _regex = regex.endsWith(this.data);
    this.operator = this.regex(_regex);
};

Expression.prototype.doesNotEndWith = function () {
    var _regex = regex.doesNotEndWith(this.data);
    this.operator = this.regex(_regex);
};

Expression.prototype.contains = function () {
    var _regex = regex.contains(this.data);
    this.operator = this.regex(_regex);
};

Expression.prototype.doesNotContain = function () {
    var _regex = regex.doesNotContain(this.data);
    this.operator = this.regex(_regex);
};

Expression.prototype.orthogonalContains = function () {
    // Create an array by splitting on whitespace
    var args = this.data.match(/\S+/g);

    // Apply our arguments to our orthogonal contains function
    var _regex = regex.orthogonalContains.apply(null, args);

    this.operator = this.regex(_regex);
};

Expression.prototype.isNull = function () {
    this.operator = {
        $ne: null
    };
};

Expression.prototype.isNotNull = function () {
    this.operator = {
        $exists: true
    };
};

Expression.prototype.in = function () {
    var arr = this.data.split(' ');
    this.operator = {
        $in: arr
    };
};

Expression.prototype.notIn = function () {
    var arr = this.data.split(' ');
    this.operator = {
        $nin: arr
    };
};

/**
 * Creates object for easy filter mappings
 * @param  {string} key The operator key required for MongoDB
 * @return {obj} MongoDB expression
 *
 * #Example
 * Original: {field:'MasterPrice', op: 'le', data:12}
 * Executed: mappedOperator('$lte');
 * New (return): { $lte: 12 }
 */
Expression.prototype.mappedOperator = function (key) {
    this.operator[key] = this.data;
};

/**
 * Creates the regex operator
 * @param  {string} pattern The fully built regular expression pattern
 * @param  {string} options Flags for the regular expression
 * @return {obj} MongoDB $regex
 */
Expression.prototype.regex = function (pattern, options) {
    options = options || 'i';
    return {
        $regex: pattern,
        $options: options
    };
};


function Query(filter) {
    this.filter = filter;

    // Stores our final MongoDB query, built from our Expression(s)
    this.query = {};

    this.init();
}

Query.prototype.init = function () {
    // Figure out what our first filter operator is to setup our query
    var rootLogicGate = (this.filter.groupOp == 'AND') ? '$and' : '$or';

    // Assigns either $and/$or based on root filter 'operator'
    this.query[rootLogicGate] = [];

    this.convertToExpressions(this.filter, this.query);
};

Query.prototype.convertToExpressions = function (filter, query) {
    var _rulesLen = filter.rules.length,
		_groupLen = (filter.groups !== void 0) ? filter.groups.length : 0,
		_query = {},
		logicGate = filter.groupOp;

    // Lets us know what the existing logic gate is.  This is useful
    // for determining where to push data
    var existingLogicGate = ('$and' in query) ? '$and' : '$or';

    // Iterate through each rule and create a Expression
    for (var i = 0; i < _rulesLen; i++) {
        var expression = new Expression(filter.rules[i]);

        // $ands work fine all grouped as one object, $or on the other hand needs to be seperate objects
        if (existingLogicGate == '$and') {
            // Add our expression to our current query object
            _query[expression.field] = expression.operator;
        } else {
            // Push our $or directly into array, or else it wont filter correctly.
            // May have to revisit if there are strongly grouped $or's
            var _orQuery = {};
            _orQuery[expression.field] = expression.operator;
            query[existingLogicGate].push(_orQuery);
        }


    }

    // Push our current query into our existing query if $and...otherwise $or's were pushed
    // individually for mongodb to evaluate $or appropriately
    if (existingLogicGate == '$and')
        query[existingLogicGate].push(_query);



    // There are children filters, so lets hook them up
    if (_groupLen > 0) {
        for (var x = 0; x < _groupLen; x++) {
            var groupOp = filter.groups[x].groupOp,
				groupLogicGate = (groupOp == 'AND') ? '$and' : '$or';

            var newGroup = {};
            newGroup[groupLogicGate] = [];
            query[existingLogicGate].push(newGroup);

            this.convertToExpressions(filter.groups[x], query[existingLogicGate][query[existingLogicGate].length - 1]);
        }
    }
};


module.exports = function (filter) {
    if (!filter.groupOp)
        throw new Error('Filter does not contain groupOp.');


    // Set some default values for rules and groups
    filter.rules = filter.rules || [];
    filter.groups = filter.groups || [];

    // See if our filter has any valid filter data to create query,
    // if not return null
    if (filter.rules.length === 0 && filter.groups.length === 0)
        return null;

    var query = new Query(filter);
    return query;
};